﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestParkingChargeCalculator
{
    [TestClass]
    public class UnitTestFactories
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
