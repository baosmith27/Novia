﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestParkingChargeCalculator
{
    [TestClass]
    public class UnitTestShortStay
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
