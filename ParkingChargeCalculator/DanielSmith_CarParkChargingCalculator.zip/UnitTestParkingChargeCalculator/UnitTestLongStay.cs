﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestParkingChargeCalculator
{
    [TestClass]
    public class UnitTestLongStay
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
