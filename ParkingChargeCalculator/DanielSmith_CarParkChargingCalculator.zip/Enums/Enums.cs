﻿namespace Enums
{
    public enum ParkingStrategyType
    {
        ShortStay,
        LongStay
    }

    public enum ChargingUnit
    {
        Hour, Day
    }
}
